# ANJAR Setup Script
# Right-click this file -> Run with PowerShell
# (Does NOT overwrite package.json / app.json — those ship correct.)

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  ANJAR SETUP — Expo SDK 52" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $dir
Write-Host "Working in: $dir" -ForegroundColor Gray

# ── Check tooling ──
Write-Host "[1/4] Checking Node + npm..." -ForegroundColor Yellow
try {
  $nodeV = node -v
  $npmV  = npm -v
  Write-Host "  node $nodeV / npm $npmV" -ForegroundColor Green
} catch {
  Write-Host "  ERROR: Node.js not found. Install Node 20 LTS from https://nodejs.org then re-run." -ForegroundColor Red
  Read-Host "Press Enter to exit"; exit 1
}

# ── Validate config files ──
Write-Host "[2/4] Validating package.json + app.json..." -ForegroundColor Yellow
foreach ($f in @("package.json","app.json")) {
  if (-not (Test-Path $f)) { Write-Host "  ERROR: $f missing." -ForegroundColor Red; Read-Host "Press Enter to exit"; exit 1 }
  try { Get-Content $f -Raw | ConvertFrom-Json | Out-Null; Write-Host "  $f OK" -ForegroundColor Green }
  catch { Write-Host "  ERROR: $f is invalid JSON: $_" -ForegroundColor Red; Read-Host "Press Enter to exit"; exit 1 }
}

# ── Clean install ──
Write-Host "[3/4] Clean npm install (2-3 minutes)..." -ForegroundColor Yellow
if (Test-Path "node_modules")       { Remove-Item -Recurse -Force "node_modules"; Write-Host "  Removed old node_modules" -ForegroundColor Gray }
if (Test-Path "package-lock.json")  { Remove-Item "package-lock.json"; Write-Host "  Removed old package-lock.json" -ForegroundColor Gray }
npm install
if ($LASTEXITCODE -ne 0) { Write-Host "  npm install FAILED — see errors above." -ForegroundColor Red; Read-Host "Press Enter to exit"; exit 1 }

# ── Align native module versions with the installed Expo SDK ──
Write-Host "[4/4] Verifying Expo dependency versions..." -ForegroundColor Yellow
npx expo install --check

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  SETUP COMPLETE" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Build a shareable APK with:" -ForegroundColor Cyan
Write-Host "  npx eas-cli build --platform android --profile preview" -ForegroundColor White
Write-Host ""
$go = Read-Host "Run the cloud build now? (y/N)"
if ($go -eq "y" -or $go -eq "Y") { npx eas-cli build --platform android --profile preview }
